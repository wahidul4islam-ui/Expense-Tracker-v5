APK build (GitHub Actions)
1. Put all these files in the root of your repo (index.html, sw.js, manifest.webmanifest, icons, .github/workflows/build-apk.yml).
2. Push. Open Actions > Build APK > download "expense-tracker-apk".
3. To keep your data when updating: make one fixed key once and save it as a repo secret named DEBUG_KEYSTORE_BASE64:
   keytool -genkey -v -keystore debug.keystore -storepass android -alias androiddebugkey -keypass android -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=Android Debug,O=Android,C=US"
   base64 -w0 debug.keystore   (paste the output as the secret)
   If your old APK was signed by another key, install this one after taking a backup (Settings > Backup).
